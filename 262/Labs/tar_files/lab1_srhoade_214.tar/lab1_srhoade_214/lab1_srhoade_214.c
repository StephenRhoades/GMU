/*
 * Stpehen Rhaodes G01369048
 * CS 262, Lab section 214
 * lab1: creating basic Unix and C code (Hello World) and directories
 */

#include <stdio.h>

int main(){
	char name[100] = "Stephen Rhoades";
	printf("Hello World!\nMy name is %s\n", name);
	return 0;
}
